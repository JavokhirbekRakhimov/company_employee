create function find_all_roles() returns json
    language plpgsql
as
$$
declare
    message varchar;
    success boolean;
    content json;
    httpStatus smallint;
    BEGIN
        content=(select json_agg(result)from (select * from role order by id) as result);
        message='Ok';
        success=true;
        httpStatus=200;
        return jsonb_build_object('message',message,'success',success,'content',content,'httpStatus',httpStatus);
    end;
$$;

alter function find_all_roles() owner to postgres;

