create function find_by_id_role(in_id smallint) returns json
    language plpgsql
as
$$
declare
    message    varchar;
    success    boolean;
    content    json;
    httpStatus smallint;
BEGIN
    success = (select exists(select * from role where id = in_id));
    if success = false then
        message = 'Role not found ';
        httpStatus = 404;
        content = '{}';
        return jsonb_build_object('message', message, 'success', success, 'content', content, 'httpStatus', httpStatus);
    else
        content = (select json_build_object('id', r.id, 'name', r.name, 'rank', r.rank)
                   from role r
                   where id = in_id
                   limit 1);
        message = 'Ok';
        success = true;
        httpStatus = 200;
        return jsonb_build_object('message', message, 'success', success, 'content', content, 'httpStatus', httpStatus);
    end if;
end;
$$;

alter function find_by_id_role(smallint) owner to postgres;

