create function update_role(in_json text) returns json
    language plpgsql
as
$$
declare
        message    varchar;
        success    boolean;
        content    json;
        httpStatus smallint;
        /* aditional */
        in_id      smallint;
    BEGIN
    in_id=(select id from json_populate_record(NULL::role_type,in_json::json));
    update role set rank=(select rank from json_populate_record(Null::role_type,in_json::json)) where id=in_id;
    content=(select row_to_json(r) from role r where id=in_id);
    message='Update';
    success=true;
    httpStatus=200;
    return jsonb_build_object('message', message, 'success', success, 'content', content, 'httpStatus', httpStatus);
end ;
$$;

alter function update_role(text) owner to postgres;

