create function find_all_roles(in_size smallint, in_page smallint) returns json
    language plpgsql
as
$$
declare
    message    varchar;
    success    boolean;
    content    json;
    httpStatus smallint;
    size smallint:=in_size;
    totalElements smallint;
    page smallint:=in_page;

BEGIN
    totalElements=(select count(id) from role );
    content = (select json_agg(result) from (select * from role order by id limit size offset size*page) as result);
    if content is null THEN
        content:='[]';
    end if;
    message = 'Ok';
    success = true;
    httpStatus = 200;
    return jsonb_build_object('message', message, 'success', success, 'content', content, 'httpStatus', httpStatus,'size',size,'page',page,'totalElements',totalElements);
end
$$;

alter function find_all_roles(smallint, smallint) owner to postgres;

